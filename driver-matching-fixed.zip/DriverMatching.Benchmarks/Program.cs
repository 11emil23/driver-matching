using BenchmarkDotNet.Running;

BenchmarkRunner.Run<DriverMatching.Benchmarks.NearestBenchmarks>();
