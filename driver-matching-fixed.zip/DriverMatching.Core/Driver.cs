namespace DriverMatching.Core;

public readonly record struct Driver(int Id, int X, int Y);
